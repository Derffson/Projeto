const API_URL = "https://sheetdb.io/api/v1/SEU_ID_AQUI"; // substitua com sua URL do SheetDB

// Gera ou obtém um ID único para o usuário
function getUserId() {
  let userId = localStorage.getItem("userId");
  if (!userId) {
    userId = 'user-' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem("userId", userId);
  }
  return userId;
}

// Salvar escala na planilha via API (apenas admin)
document.getElementById("escalaForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  const form = e.target;

  const novaEscala = {
    data: form.dataEscala.value,
    vocal: form.vocal.value.trim(),
    segundaVoz: form.segundaVoz.value.trim(),
    baterista: form.baterista.value.trim(),
    guitarrista: form.guitarrista.value.trim(),
    baixista: form.baixista.value.trim(),
    violonista: form.violonista.value.trim(),
  };

  if (!novaEscala.data) {
    alert("Informe a data da escala.");
    return;
  }

  try {
    // Deleta escala existente para evitar duplicadas
    await fetch(`${API_URL}/search?data=${novaEscala.data}`, {
      method: 'DELETE',
    });

    // Adiciona nova escala
    await fetch(API_URL, {
      method: 'POST',
      body: JSON.stringify({ data: [novaEscala] }),
      headers: { 'Content-Type': 'application/json' }
    });

    alert("Escala salva com sucesso!");
    form.reset();
    atualizarCalendario();
  } catch (error) {
    alert("Erro ao salvar escala.");
    console.error(error);
  }
});

async function buscarEscala() {
  const data = document.getElementById("dataBusca").value;
  if (!data) {
    alert("Selecione uma data para buscar.");
    return;
  }
  mostrarEscala(data);
}

async function mostrarEscala(data) {
  const container = document.getElementById("escalaSalva");

  try {
    const res = await fetch(`${API_URL}/search?data=${data}`);
    const escalas = await res.json();
    const dados = escalas[0];

    if (!dados) {
      container.innerHTML = `<p><strong>Nenhuma escala cadastrada para ${data}.</strong></p>`;
      return;
    }

    // Votação (ainda usando localStorage)
    let votosPaleta = JSON.parse(localStorage.getItem("votosPaleta")) || {};
    let votosData = votosPaleta[data] || {};

    let votosUsuarios = JSON.parse(localStorage.getItem("votosUsuarios")) || {};
    let votosDataUsuarios = votosUsuarios[data] || {};

    const userId = getUserId();
    const votoAtualUsuario = votosDataUsuarios[userId];

    const PALETAS = [
      "Tons de Cinza",
      "Tons de Bege",
      "Jeans com Bege",
      "Jeans com Preto"
    ];

    function montarBotoes() {
      return PALETAS.map(paleta => {
        const votos = votosData[paleta] || 0;
        const isSelecionado = votoAtualUsuario === paleta;
        return `
          <button 
            style="
              margin:4px; padding:6px 10px; border-radius:6px; cursor:pointer;
              ${isSelecionado ? 'background-color:#4CAF50; color:#fff;' : ''}
            " 
            onclick="registrarVoto('${data}', '${paleta}')"
            title="Votos: ${votos}"
          >
            ${paleta} (${votos} voto${votos !== 1 ? 's' : ''})
          </button>
        `;
      }).join('');
    }

    const isAdmin = document.getElementById("areaAdmin").style.display === "block";

    container.innerHTML = `
      <h2>Escala da Semana (${data})</h2>
      <p><strong>Vocal:</strong> ${dados.vocal}</p>
      <p><strong>Segunda Voz:</strong> ${dados.segundaVoz}</p>
      <p><strong>Baterista:</strong> ${dados.baterista}</p>
      <p><strong>Guitarrista:</strong> ${dados.guitarrista}</p>
      <p><strong>Baixista:</strong> ${dados.baixista}</p>
      <p><strong>Violonista:</strong> ${dados.violonista}</p>

      <h3>Vote na Paleta de Cores para essa semana:</h3>
      <div id="votacao-paleta">
        ${montarBotoes()}
      </div>

      ${isAdmin ? `
        <button onclick="editarEscala('${data}')">Editar</button>
        <button class="botao-secundario" onclick="excluirEscala('${data}')">Excluir</button>
      ` : ''}
    `;
  } catch (error) {
    console.error("Erro ao buscar escala:", error);
    container.innerHTML = "<p>Erro ao carregar escala.</p>";
  }
}

// Registro de votos (continua com localStorage)
function registrarVoto(data, paleta) {
  const userId = getUserId();

  let votosPaleta = JSON.parse(localStorage.getItem("votosPaleta")) || {};
  if (!votosPaleta[data]) votosPaleta[data] = {};

  let votosUsuarios = JSON.parse(localStorage.getItem("votosUsuarios")) || {};
  if (!votosUsuarios[data]) votosUsuarios[data] = {};

  const votoAnterior = votosUsuarios[data][userId];

  if (votoAnterior) {
    votosPaleta[data][votoAnterior] = (votosPaleta[data][votoAnterior] || 1) - 1;
  }

  votosUsuarios[data][userId] = paleta;
  votosPaleta[data][paleta] = (votosPaleta[data][paleta] || 0) + 1;

  localStorage.setItem("votosPaleta", JSON.stringify(votosPaleta));
  localStorage.setItem("votosUsuarios", JSON.stringify(votosUsuarios));

  mostrarEscala(data);
}

// Editar escala (preenche o form)
async function editarEscala(data) {
  const res = await fetch(`${API_URL}/search?data=${data}`);
  const dados = (await res.json())[0];
  if (!dados) return alert("Escala não encontrada.");

  const form = document.getElementById("escalaForm");
  form.dataEscala.value = data;
  form.vocal.value = dados.vocal;
  form.segundaVoz.value = dados.segundaVoz;
  form.baterista.value = dados.baterista;
  form.guitarrista.value = dados.guitarrista;
  form.baixista.value = dados.baixista;
  form.violonista.value = dados.violonista;

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Excluir escala
async function excluirEscala(data) {
  if (!confirm(`Tem certeza que deseja excluir a escala do dia ${data}?`)) return;
  await fetch(`${API_URL}/search?data=${data}`, { method: 'DELETE' });
  document.getElementById("escalaSalva").innerHTML = "";
  atualizarCalendario();
  alert("Escala excluída.");
}

// Calendário
document.addEventListener("DOMContentLoaded", () => iniciarCalendario());

let calendar;

async function iniciarCalendario() {
  const calendarEl = document.getElementById("calendario");
  calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: "dayGridMonth",
    locale: "pt-br",
    events: await gerarEventos(),
    eventClick: function (info) {
      const data = info.event.startStr;
      mostrarEscala(data);
      document.getElementById("dataBusca").value = data;
    }
  });
  calendar.render();
}

async function gerarEventos() {
  const res = await fetch(API_URL);
  const dados = await res.json();
  return dados.map(escala => ({
    title: "Escala",
    start: escala.data,
    backgroundColor: "#3a87ad",
    borderColor: "#3a87ad"
  }));
}

function atualizarCalendario() {
  if (!calendar) return;
  calendar.removeAllEvents();
  gerarEventos().then(eventos => {
    calendar.addEventSource(eventos);
    calendar.refetchEvents();
  });
}

// Modo admin
function ativarModoAdmin() {
  const senha = prompt("Digite a senha de administrador:");
  if (senha === "louvor2024") {
    document.getElementById("areaAdmin").style.display = "block";
    document.getElementById("btnAdmin").style.display = "none";
    atualizarCalendario();
  } else {
    alert("Senha incorreta.");
  }
}
